import os
from abc import ABC, abstractmethod


class TicketContent(ABC):

    def __init__(self, path):
        self.path = path

    @abstractmethod
    def load(self):
        pass

    @abstractmethod
    def export_to_pdf(self):
        pass


class TextContent(TicketContent):

    def load(self):
        if not os.path.exists(self.path):
            print(f"[Texte] Erreur : fichier introuvable ({self.path})")
            return None

        try:
            with open(self.path, "r", encoding="utf-8") as fichier:
                contenu = fichier.read()
        except UnicodeDecodeError:
            print(
                f"[Texte] Erreur : {self.path} n'est pas lisible comme "
                f"du texte UTF-8 (mauvais encodage, ou ce n'est pas "
                f"vraiment un fichier texte)."
            )
            return None
        except OSError as erreur:
            print(f"[Texte] Erreur de lecture de {self.path} : {erreur}")
            return None

        print(f"[Texte] Contenu chargé depuis {self.path}")
        return contenu

    def export_to_pdf(self):
        print(
            f"[Texte] Le texte de {self.path} "
            f"est inséré tel quel dans le PDF."
        )


class ImageContent(TicketContent):

    def load(self):
        if not os.path.exists(self.path):
            print(f"[Image] Erreur : fichier introuvable ({self.path})")
            return None

        print(f"[Image] Image chargée depuis {self.path}")
        return self.path

    def export_to_pdf(self):
        print(
            f"[Image] L'image {self.path} "
            f"est incrustée directement dans le PDF."
        )


class VideoContent(TicketContent):

    def load(self):
        if not os.path.exists(self.path):
            print(f"[Vidéo] Erreur : fichier introuvable ({self.path})")
            return None

        print(
            f"[Vidéo] Référence vidéo prête pour lecture "
            f"en flux : {self.path}"
        )
        return self.path

    def export_to_pdf(self):
        print(
            f"[Vidéo] Une vidéo ne peut pas être intégrée dans un "
            f"PDF statique. Insertion d'un lien vers {self.path} à la place."
        )


def create_content(type_choix, path):
    """Fabrique simple : centralise la décision de quelle sous-classe
    de TicketContent instancier, selon le type choisi par l'utilisateur."""

    types = {
        "1": TextContent,
        "2": ImageContent,
        "3": VideoContent
    }

    classe = types.get(type_choix)

    if classe is None:
        return None

    return classe(path)