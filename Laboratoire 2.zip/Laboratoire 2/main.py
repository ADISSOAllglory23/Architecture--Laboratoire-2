from User import User
from Admin import Admin
from Ticket import Ticket
from Content import create_content


def demander_entier(message):
    while True:
        try:
            return int(input(message))
        except ValueError:
            print("Veuillez entrer un nombre entier.")


def trouver_ticket(tickets, ticket_id):
    for ticket in tickets:
        if ticket.ticket_id == ticket_id:
            return ticket
    return None


def demander_contenu():
    print("1. Texte")
    print("2. Image")
    print("3. Vidéo")
    type_choix = input("Type de contenu : ")
    path = input("Chemin du fichier : ")
    return create_content(type_choix, path)


def menu_user(user, tickets):

    while True:
        print(f"\n===== MENU USER : {user.name} =====")
        print("1. Créer un ticket")
        print("2. Voir un ticket")
        print("3. Modifier le titre d'un ticket")
        print("4. Ajouter un commentaire")
        print("5. Ajouter un contenu (texte/image/vidéo)")
        print("6. Exporter un ticket en PDF")
        print("0. Retour")

        choix = input("Votre choix : ")

        if choix == "1":
            ticket_id = demander_entier("ID du ticket : ")
            title = input("Titre : ")
            priority = input("Priorité : ")

            ticket = Ticket(ticket_id, title, priority)

            tickets.append(ticket)
            user.create_ticket(ticket)

            print("Ticket créé avec succès.")

            while True:
                reponse = input("Ajouter un contenu à ce ticket ? (o/n) : ")

                if reponse.lower() != "o":
                    break

                content = demander_contenu()

                if content is None:
                    print("Type de contenu invalide.")
                else:
                    ticket.add_content(content)

        elif choix == "2":
            ticket_id = demander_entier("ID du ticket : ")

            ticket = trouver_ticket(tickets, ticket_id)

            if ticket is None:
                print("Ticket introuvable.")
            else:
                print(f"ID : {ticket.ticket_id}")
                print(f"Titre : {ticket.title}")
                print(f"Statut : {ticket.status}")
                print(f"Priorité : {ticket.priority}")

                if len(ticket.contents) == 0:
                    print("Aucun contenu associé à ce ticket.")
                else:
                    print("Contenus :")
                    for content in ticket.contents:
                        print(
                            f"- {content.__class__.__name__} "
                            f"({content.path})"
                        )
                        content.load()

        elif choix == "3":
            ticket_id = demander_entier("ID du ticket : ")

            ticket = trouver_ticket(tickets, ticket_id)

            if ticket is None:
                print("Ticket introuvable.")
            else:
                title = input("Nouveau titre : ")
                ticket.title = title

                user.update_ticket(ticket)

                print("Ticket modifié.")

        elif choix == "4":
            ticket_id = demander_entier("ID du ticket : ")

            ticket = trouver_ticket(tickets, ticket_id)

            if ticket is None:
                print("Ticket introuvable.")
            else:
                commentaire = input("Commentaire : ")
                ticket.add_comment(commentaire)
                print("Commentaire ajouté.")

        elif choix == "5":
            ticket_id = demander_entier("ID du ticket : ")

            ticket = trouver_ticket(tickets, ticket_id)

            if ticket is None:
                print("Ticket introuvable.")
            else:
                content = demander_contenu()

                if content is None:
                    print("Type de contenu invalide.")
                else:
                    ticket.add_content(content)

        elif choix == "6":
            ticket_id = demander_entier("ID du ticket : ")

            ticket = trouver_ticket(tickets, ticket_id)

            if ticket is None:
                print("Ticket introuvable.")
            elif len(ticket.contents) == 0:
                print("Aucun contenu à exporter.")
            else:
                print(f"--- Export PDF du ticket {ticket.ticket_id} ---")
                for content in ticket.contents:
                    content.export_to_pdf()

        elif choix == "0":
            break

        else:
            print("Choix invalide.")


def menu_admin(admin, users, tickets):

    while True:
        print(f"\n===== MENU ADMIN : {admin.name} =====")
        print("1. Assigner un ticket")
        print("2. Fermer un ticket")
        print("3. Voir tous les tickets")
        print("4. Modifier le statut d'un ticket")
        print("0. Retour")

        choix = input("Votre choix : ")

        if choix == "1":
            ticket_id = demander_entier("ID du ticket : ")
            user_id = demander_entier("ID de l'utilisateur : ")

            ticket = trouver_ticket(tickets, ticket_id)

            user = None
            for u in users:
                if u.user_id == user_id:
                    user = u
                    break

            if ticket is None:
                print("Ticket introuvable.")

            elif user is None:
                print("Utilisateur introuvable.")

            else:
                admin.assign_ticket(ticket, user)
                print("Ticket assigné.")

        elif choix == "2":
            ticket_id = demander_entier("ID du ticket : ")

            ticket = trouver_ticket(tickets, ticket_id)

            if ticket is None:
                print("Ticket introuvable.")
            else:
                admin.close_ticket(ticket)
                print("Ticket fermé.")

        elif choix == "3":
            if len(tickets) == 0:
                print("Aucun ticket.")
            else:
                for ticket in tickets:
                    print(
                        f"ID : {ticket.ticket_id} | "
                        f"Titre : {ticket.title} | "
                        f"Statut : {ticket.status} | "
                        f"Contenus : {len(ticket.contents)}"
                    )

        elif choix == "4":
            ticket_id = demander_entier("ID du ticket : ")

            ticket = trouver_ticket(tickets, ticket_id)

            if ticket is None:
                print("Ticket introuvable.")
            else:
                print("1. OUVERT")
                print("2. ASSIGNE")
                print("3. VALIDATION")
                print("4. TERMINE")

                choix_statut = input("Nouveau statut : ")

                statuts = {
                    "1": "OUVERT",
                    "2": "ASSIGNE",
                    "3": "VALIDATION",
                    "4": "TERMINE"
                }

                if choix_statut in statuts:
                    ticket.update_status(
                        statuts[choix_statut]
                    )
                    print("Statut modifié.")
                else:
                    print("Statut invalide.")

        elif choix == "0":
            break

        else:
            print("Choix invalide.")


def main():

    users = []
    admins = []
    tickets = []

    while True:

        print("\n===== GESTIONNAIRE DE TICKETS =====")
        print("1. User")
        print("2. Admin")
        print("0. Quitter")

        choix = input("Votre choix : ")

        if choix == "1":

            print("\n--- Identification User ---")

            user_id = demander_entier("ID : ")
            name = input("Nom : ")
            email = input("Email : ")
            role = input("Rôle : ")

            user = User(
                user_id,
                name,
                email,
                role
            )

            users.append(user)

            menu_user(user, tickets)

        elif choix == "2":

            print("\n--- Identification Admin ---")

            admin_id = demander_entier("ID : ")
            name = input("Nom : ")
            email = input("Email : ")

            admin = Admin(
                admin_id,
                name,
                email
            )

            admins.append(admin)

            menu_admin(
                admin,
                users,
                tickets
            )

        elif choix == "0":
            print("Fermeture du programme.")
            break

        else:
            print("Choix invalide.")


if __name__ == "__main__":
    main()
