class Admin:

    def __init__(self, admin_id, name, email):
        self.admin_id = admin_id
        self.name = name
        self.email = email
        self.tickets = []

    def assign_ticket(self, ticket, user):
        ticket.assign_to(user)

        if ticket not in self.tickets:
            self.tickets.append(ticket)

        print(
            f"{self.name} a assigne le ticket "
            f"{ticket.title} à {user.name}"
        )

    def close_ticket(self, ticket):
        ticket.update_status("TERMINE")

        print(
            f"{self.name} a ferme le ticket "
            f"{ticket.title}"
        )

    def view_all_tickets(self):
        return self.tickets
