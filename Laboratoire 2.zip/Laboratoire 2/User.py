class User:

    def __init__(self, user_id, name, email, role):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.role = role

    def create_ticket(self, ticket):
        print(f"{self.name} a cree le ticket {ticket.title}")

    def view_ticket(self, ticket):
        print(f"--- Ticket vu par {self.name} ---")
        print(f"ID: {ticket.ticket_id}")
        print(f"Titre: {ticket.title}")
        print(f"Statut: {ticket.status}")

    def update_ticket(self, ticket):
        print(
            f"{self.name} a mis à jour "
            f"le ticket {ticket.ticket_id}"
        )
