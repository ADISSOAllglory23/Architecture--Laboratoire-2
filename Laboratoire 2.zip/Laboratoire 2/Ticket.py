from datetime import datetime


class Ticket:
    def __init__(self, ticket_id, title, priority):
        self.ticket_id = ticket_id
        self.title = title
        self.status = "OUVERT"
        self.priority = priority

        self.creation_date = datetime.now()
        self.update_date = datetime.now()

        self.assigned_to = None
        self.comments = []
        self.contents = []

    def assign_to(self, user):
        self.assigned_to = user
        self.status = "ASSIGNE"
        self.update_date = datetime.now()

        print(
            f"Le ticket {self.ticket_id} "
            f"est assigne a {user.name}"
        )

    def update_status(self, status):
        self.status = status
        self.update_date = datetime.now()

        print(
            f"Le ticket {self.ticket_id} "
            f"est maintenant au statut : {self.status}"
        )

    def add_comment(self, comment):
        self.comments.append(comment)
        self.update_date = datetime.now()

        print(
            f"Commentaire ajoute au ticket "
            f"{self.ticket_id} : {comment}"
        )

    def add_content(self, content):
        self.contents.append(content)
        self.update_date = datetime.now()

        print(
            f"Contenu ({content.__class__.__name__}) ajoute "
            f"au ticket {self.ticket_id} : {content.path}"
        )
